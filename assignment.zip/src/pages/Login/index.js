import React from 'react';
import "./index.scss";

const Login = ({}) => {

    return (
        <div>
            Login Page
        </div>
    );
};

Login.propTypes = {

};

export default Login;
