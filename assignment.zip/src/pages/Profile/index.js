import React from 'react';
import "./index.scss";

const Profile = ({}) => {

    return (
        <div>
            Profile Page
        </div>
    );
};

Profile.propTypes = {

};

export default Profile;
